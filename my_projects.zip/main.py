from codrone_edu.drone import *

drone = Drone()
drone.connect()

# Welcome to Python for Robolink! Write your Python code below.

drone.disconnect()